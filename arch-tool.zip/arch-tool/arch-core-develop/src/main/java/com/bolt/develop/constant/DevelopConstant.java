
package com.bolt.develop.constant;

/**
 * 系统常量.
 *
 * @author arch_group
 */
public interface DevelopConstant {
	/**
	 * tom 系统名
	 */
	String TOM_NAME = "tom";

	/**
	 * jerry 系统名
	 */
	String JERRY_NAME = "herry";
}
