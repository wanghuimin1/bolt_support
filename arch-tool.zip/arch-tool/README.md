
## 工程结构
``` 
arch-tool
├── arch-core-boot -- 业务包综合模块
├── arch-core-launch -- 基础启动模块
├── arch-core-log -- 日志封装模块 
├── arch-core-mybatis -- mybatis拓展封装模块 
├── arch-core-secure -- 安全模块 
├── arch-core-swagger -- swagger拓展封装模块 
└── arch-core-tool -- 工具包模块 
	 
```
