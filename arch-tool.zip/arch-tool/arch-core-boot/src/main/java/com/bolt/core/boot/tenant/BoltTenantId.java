
package com.bolt.core.boot.tenant;

import com.bolt.core.tool.utils.RandomType;
import com.bolt.core.tool.utils.StringUtil;

/**
 * bolt租户id生成器
 *
 * @author arch_group
 */
public class BoltTenantId implements TenantId {
	@Override
	public String generate() {
		return StringUtil.random(6, RandomType.INT);
	}
}
