
package com.bolt.core.boot.tenant;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 多租户配置
 *
 * @author arch_group
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "bolt.tenant")
public class BoltTenantProperties {

	/**
	 * 多租户字段名称
	 */
	private String column = "tenant_code";

	/**
	 * 多租户数据表
	 */
	private List<String> tables = new ArrayList<>();

	/**
	 * 多租户系统数据表
	 */
	private List<String> boltTables = Arrays.asList("bolt_notice", "bolt_log_api", "bolt_log_error", "bolt_log_usual");
}
