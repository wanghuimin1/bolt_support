package com.bolt.core.mp.base;

import com.baomidou.mybatisplus.extension.service.IService;

import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * 基础业务接口
 *
 * @param <T>
 * @author arch_group
 */
public interface BoltService<T> extends IService<T>{

}
