
package com.bolt.core.secure.config;


import com.bolt.core.secure.aspect.AuthAspect;
import com.bolt.core.secure.props.BoltClientProperties;
import com.bolt.core.secure.props.BoltSecureProperties;
import lombok.AllArgsConstructor;
import com.bolt.core.secure.interceptor.ClientInterceptor;
import com.bolt.core.secure.interceptor.SecureInterceptor;
import com.bolt.core.secure.provider.ClientDetailsServiceImpl;
import com.bolt.core.secure.provider.IClientDetailsService;
import com.bolt.core.secure.registry.SecureRegistry;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 安全配置类
 *
 * @author arch_group
 */
@Order
@Configuration
@AllArgsConstructor
@EnableConfigurationProperties({BoltSecureProperties.class, BoltClientProperties.class})
public class SecureConfiguration implements WebMvcConfigurer {

	private final SecureRegistry secureRegistry;

	private final BoltSecureProperties secureProperties;

	private final BoltClientProperties clientProperties;

	private final JdbcTemplate jdbcTemplate;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		clientProperties.getClient().forEach(cs -> registry.addInterceptor(new ClientInterceptor(cs.getClientId())).addPathPatterns(cs.getPathPatterns()));

		if (secureRegistry.isEnable()) {
			registry.addInterceptor(new SecureInterceptor())
				.excludePathPatterns(secureRegistry.getExcludePatterns())
				.excludePathPatterns(secureRegistry.getDefaultExcludePatterns())
				.excludePathPatterns(secureProperties.getExcludePatterns());
		}
	}

	@Bean
	public AuthAspect authAspect() {
		return new AuthAspect();
	}

	@Bean
	@ConditionalOnMissingBean(IClientDetailsService.class)
	public IClientDetailsService clientDetailsService() {
		return new ClientDetailsServiceImpl(jdbcTemplate);
	}

}
