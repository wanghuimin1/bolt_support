
package com.bolt.core.launch.constant;

/**
 * sentinel配置.
 *
 * @author arch_group
 */
public interface SentinelConstant {

	/**
	 * sentinel 地址
	 */
	String SENTINEL_ADDR = "127.0.0.1:8858";
}
