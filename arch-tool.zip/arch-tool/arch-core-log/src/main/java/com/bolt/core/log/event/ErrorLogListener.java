
package com.bolt.core.log.event;


import com.bolt.core.log.constant.EventConstant;
import com.bolt.core.log.feign.ILogClient;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import com.bolt.core.launch.props.BoltProperties;
import com.bolt.core.launch.server.ServerInfo;
import com.bolt.core.log.model.LogError;
import com.bolt.core.secure.utils.SecureUtil;
import com.bolt.core.tool.utils.WebUtil;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.Async;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * 异步监听错误日志事件
 *
 * @author arch_group
 */
@Slf4j
@AllArgsConstructor
public class ErrorLogListener {

	private final ILogClient logService;
	private final ServerInfo serverInfo;
	private final BoltProperties boltProperties;

	@Async
	@Order
	@EventListener(ErrorLogEvent.class)
	public void saveErrorLog(ErrorLogEvent event) {
		Map<String, Object> source = (Map<String, Object>) event.getSource();
		LogError logError = (LogError) source.get(EventConstant.EVENT_LOG);
		HttpServletRequest request = (HttpServletRequest) source.get(EventConstant.EVENT_REQUEST);
		logError.setUserAgent(request.getHeader(WebUtil.USER_AGENT_HEADER));
		logError.setMethod(request.getMethod());
		logError.setParams(WebUtil.getRequestParamString(request));
		logError.setServiceId(boltProperties.getName());
		logError.setServerHost(serverInfo.getHostName());
		logError.setServerIp(serverInfo.getIpWithPort());
		logError.setEnv(boltProperties.getEnv());
		logError.setCreateBy(SecureUtil.getUserAccount(request));
		logError.setCreateTime(LocalDateTime.now());
		logService.saveErrorLog(logError);
	}

}
