

package com.bolt.core.log.config;

import com.bolt.core.log.aspect.ApiLogAspect;
import com.bolt.core.log.logger.BoltLogger;
import lombok.AllArgsConstructor;
import com.bolt.core.log.event.ApiLogListener;
import com.bolt.core.log.event.UsualLogListener;
import com.bolt.core.log.event.ErrorLogListener;
import com.bolt.core.launch.props.BoltProperties;
import com.bolt.core.launch.server.ServerInfo;
import com.bolt.core.log.feign.ILogClient;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 日志工具自动配置
 *
 * @author arch_group
 */
@Configuration
@AllArgsConstructor
@ConditionalOnWebApplication
public class BoltLogToolAutoConfiguration {

	private final ILogClient logService;
	private final ServerInfo serverInfo;
	private final BoltProperties boltProperties;

	@Bean
	public ApiLogAspect apiLogAspect() {
		return new ApiLogAspect();
	}

	@Bean
	public BoltLogger boltLogger() {
		return new BoltLogger();
	}

	@Bean
	public ApiLogListener apiLogListener() {
		return new ApiLogListener(logService, serverInfo, boltProperties);
	}

	@Bean
	public ErrorLogListener errorEventListener() {
		return new ErrorLogListener(logService, serverInfo, boltProperties);
	}

	@Bean
	public UsualLogListener boltEventListener() {
		return new UsualLogListener(logService, serverInfo, boltProperties);
	}

}
