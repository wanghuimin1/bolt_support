

package com.bolt.core.log.publisher;

import com.bolt.core.log.constant.EventConstant;
import com.bolt.core.log.event.UsualLogEvent;
import com.bolt.core.log.model.LogUsual;
import com.bolt.core.tool.utils.SpringUtil;
import com.bolt.core.tool.utils.WebUtil;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * BOLT日志信息事件发送
 *
 * @author arch_group
 */
public class UsualLogPublisher {

	public static void publishEvent(String level, String id, String data) {
		HttpServletRequest request = WebUtil.getRequest();
		LogUsual logUsual = new LogUsual();
		logUsual.setLogLevel(level);
		logUsual.setLogId(id);
		logUsual.setLogData(data);
		Map<String, Object> event = new HashMap<>(16);
		event.put(EventConstant.EVENT_LOG, logUsual);
		event.put(EventConstant.EVENT_REQUEST, request);
		SpringUtil.publishEvent(new UsualLogEvent(event));
	}

}
