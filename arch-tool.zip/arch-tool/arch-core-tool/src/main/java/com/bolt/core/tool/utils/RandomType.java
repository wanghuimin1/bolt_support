
package com.bolt.core.tool.utils;

/**
 * 生成的随机数类型
 *
 * @author arch_group
 */
public enum RandomType {
	/**
	 * INT STRING ALL
	 */
	INT, STRING, ALL
}
